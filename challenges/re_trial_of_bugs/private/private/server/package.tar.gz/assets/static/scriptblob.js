scriptblob_js = [_C => {// [0]: assets/script/card_drop_area.txt:3

  _C.components = ['interactable'];
}, _C => {// [1]: assets/script/card_drop_area.txt:4

  _C.props = {
    card: 'object'
  };
}, _C => {// [2]: assets/script/card_drop_area.txt:7

  _C.self.card = 0;
}, _C => {// [3]: assets/script/card_drop_area.txt:12

  return _C.world.entities[-_C.self.card].card.canDrop;
}, _C => {// [4]: assets/script/card_drop_area.txt:13

  _C.world.entities[-_C.self.card].card.canDrop = false;
}, _C => {// [5]: assets/script/card_drop_area.txt:14

  _C.world.entities[-_C.self.card].card.collectOnCollide = false;
}, _C => {// [6]: assets/script/card_drop_area.txt:15

  _C.world.entities[-_C.self.card].transform.x = _C.playerEntity.transform.centerX;
}, _C => {// [7]: assets/script/card_drop_area.txt:16

  _C.world.entities[-_C.self.card].transform.y = _C.playerEntity.transform.centerY + 20;
}, _C => {// [8]: assets/script/challenge_select.txt:5

  _C.components = ['interactable'];
}, _C => {// [9]: assets/script/challenge_select.txt:6

  _C.props = {};
}, _C => {// [10]: assets/script/challenge_select.txt:11

  _C.interactable.interactText = "Use panel";
}, _C => {// [11]: assets/script/challenge_select.txt:14

  return _C.player.globalData.get('challenge') === _C.undefined;
}, _C => {// [12]: assets/script/challenge_select.txt:19

  _C.player.globalData.set('challenge', _C.player.globalData.get('challenge') || 'trial_of_bugs');
}, _C => {// [13]: assets/script/challenge_select.txt:21

  _C.player.globalData.set('challenge', _C.player.globalData.get('challenge') || 'trial_of_data');
}, _C => {// [14]: assets/script/challenge_select.txt:22

  _C.emit({
    type: 'tutorial_panel_interact'
  });
}, _C => {// [15]: assets/script/challenge_select.txt:24

  _C.should_enter_trial_of_bugs = _C.player.globalData.get('challenge') === 'trial_of_bugs';
}, _C => {// [16]: assets/script/challenge_select.txt:25

  _C.should_enter_trial_of_data = _C.player.globalData.get('challenge') === 'trial_of_data';
}, _C => {// [17]: assets/script/challenge_select.txt:26

  return _C.should_enter_trial_of_bugs;
}, _C => {// [18]: assets/script/challenge_select.txt:27

  _C.playerEntity.transform.x = 10125;
}, _C => {// [19]: assets/script/challenge_select.txt:28

  _C.playerEntity.transform.y = 4088;
}, _C => {// [20]: assets/script/challenge_select.txt:29

  return _C.should_enter_trial_of_data;
}, _C => {// [21]: assets/script/challenge_select.txt:30

  _C.player.quest.addQuest('trial_of_data');
}, _C => {// [22]: assets/script/challenge_select.txt:31

  _C.playerEntity.player_movement.teleportToPoint('labyrinth_respawn_1');
}, _C => {// [23]: assets/script/labyrinth_3_challenge_panel.txt:6

  _C.components = ['interactable'];
}, _C => {// [24]: assets/script/labyrinth_3_challenge_panel.txt:7

  _C.props = {
    gameFlagName: 'string'
  };
}, _C => {// [25]: assets/script/labyrinth_3_challenge_panel.txt:10

  _C.self.gameFlagName = '';
}, _C => {// [26]: assets/script/labyrinth_3_challenge_panel.txt:22
}, _C => {// [27]: assets/script/labyrinth_3_challenge_panel.txt:24

  _C.answer_1_correct = false;
}, _C => {// [28]: assets/script/labyrinth_3_challenge_panel.txt:31

  _C.answer_1_correct = true;
}, _C => {// [29]: assets/script/labyrinth_3_challenge_panel.txt:35

  _C.answer_2 = 1;
}, _C => {// [30]: assets/script/labyrinth_3_challenge_panel.txt:37

  _C.answer_2 = 2;
}, _C => {// [31]: assets/script/labyrinth_3_challenge_panel.txt:39

  _C.answer_2 = 3;
}, _C => {// [32]: assets/script/labyrinth_3_challenge_panel.txt:41

  _C.answer_2 = 4;
}, _C => {// [33]: assets/script/labyrinth_3_challenge_panel.txt:45

  _C.answer_3 = 1;
}, _C => {// [34]: assets/script/labyrinth_3_challenge_panel.txt:47

  _C.answer_3 = 2;
}, _C => {// [35]: assets/script/labyrinth_3_challenge_panel.txt:49

  _C.answer_3 = 3;
}, _C => {// [36]: assets/script/labyrinth_3_challenge_panel.txt:51

  _C.answer_3 = 4;
}, _C => {// [37]: assets/script/labyrinth_3_challenge_panel.txt:55

  _C.answer_4 = 1;
}, _C => {// [38]: assets/script/labyrinth_3_challenge_panel.txt:57

  _C.answer_4 = 2;
}, _C => {// [39]: assets/script/labyrinth_3_challenge_panel.txt:59

  _C.answer_4 = 3;
}, _C => {// [40]: assets/script/labyrinth_3_challenge_panel.txt:61

  _C.answer_4 = 4;
}, _C => {// [41]: assets/script/labyrinth_3_challenge_panel.txt:65

  _C.answer_5 = 1;
}, _C => {// [42]: assets/script/labyrinth_3_challenge_panel.txt:67

  _C.answer_5 = 2;
}, _C => {// [43]: assets/script/labyrinth_3_challenge_panel.txt:69

  _C.answer_5 = 3;
}, _C => {// [44]: assets/script/labyrinth_3_challenge_panel.txt:71

  _C.answer_5 = 4;
}, _C => {// [45]: assets/script/labyrinth_3_challenge_panel.txt:75

  _C.answer_6 = 1;
}, _C => {// [46]: assets/script/labyrinth_3_challenge_panel.txt:77

  _C.answer_6 = 2;
}, _C => {// [47]: assets/script/labyrinth_3_challenge_panel.txt:79

  _C.answer_6 = 3;
}, _C => {// [48]: assets/script/labyrinth_3_challenge_panel.txt:81

  _C.answer_6 = 4;
}, _C => {// [49]: assets/script/labyrinth_3_challenge_panel.txt:85

  _C.answer_7 = 1;
}, _C => {// [50]: assets/script/labyrinth_3_challenge_panel.txt:87

  _C.answer_7 = 2;
}, _C => {// [51]: assets/script/labyrinth_3_challenge_panel.txt:89

  _C.answer_7 = 3;
}, _C => {// [52]: assets/script/labyrinth_3_challenge_panel.txt:91

  _C.answer_7 = 4;
}, _C => {// [53]: assets/script/labyrinth_3_challenge_panel.txt:93

  _C.answer_8_correct = false;
}, _C => {// [54]: assets/script/labyrinth_3_challenge_panel.txt:99

  _C.answer_8_correct = true;
}, _C => {// [55]: assets/script/labyrinth_3_challenge_panel.txt:101

  _C.answer_9_correct = true;
}, _C => {// [56]: assets/script/labyrinth_3_challenge_panel.txt:104

  _C.answer_9_correct = false;
}, _C => {// [57]: assets/script/labyrinth_3_challenge_panel.txt:107

  _C.answer_9_correct = false;
}, _C => {// [58]: assets/script/labyrinth_3_challenge_panel.txt:109

  _C.answer_9_correct = false;
}, _C => {// [59]: assets/script/labyrinth_3_challenge_panel.txt:111

  _C.answer_10_correct = false;
}, _C => {// [60]: assets/script/labyrinth_3_challenge_panel.txt:116

  _C.answer_10_correct = true;
}, _C => {// [61]: assets/script/labyrinth_3_challenge_panel.txt:119

  _C.hash = 0;
}, _C => {// [62]: assets/script/labyrinth_3_challenge_panel.txt:120

  _C.hash = Math.imul(_C.hash, 0x7d0063c) ^ _C.answer_6;
}, _C => {// [63]: assets/script/labyrinth_3_challenge_panel.txt:121

  _C.hash = Math.imul(_C.hash, 0xe2a467ef) ^ _C.answer_3;
}, _C => {// [64]: assets/script/labyrinth_3_challenge_panel.txt:122

  _C.hash = _C.hash + 0x7aeaddd2 & 0xffffffff;
}, _C => {// [65]: assets/script/labyrinth_3_challenge_panel.txt:123

  _C.hash = Math.imul(_C.hash, 0x4398389c) ^ _C.answer_7;
}, _C => {// [66]: assets/script/labyrinth_3_challenge_panel.txt:124

  _C.hash = Math.imul(_C.hash, 0xb3342b2b) ^ _C.answer_5;
}, _C => {// [67]: assets/script/labyrinth_3_challenge_panel.txt:125

  _C.hash = Math.imul(_C.hash, 0xcd53a4) ^ _C.answer_4;
}, _C => {// [68]: assets/script/labyrinth_3_challenge_panel.txt:126

  _C.hash = Math.imul(_C.hash, 0x400b476b) ^ _C.answer_2;
}, _C => {// [69]: assets/script/labyrinth_3_challenge_panel.txt:128

  return _C.hash === -730341985 && _C.answer_1_correct && _C.answer_8_correct && _C.answer_9_correct && _C.answer_10_correct;
}, _C => {// [70]: assets/script/labyrinth_3_challenge_panel.txt:130

  _C.player.globalData.set(_C.self.gameFlagName, true);
}, _C => {// [71]: assets/script/labyrinth_5_challenge_coordinator.txt:5

  _C.components = [];
}, _C => {// [72]: assets/script/labyrinth_5_challenge_coordinator.txt:6

  _C.props = {};
}, _C => {// [73]: assets/script/labyrinth_5_challenge_coordinator.txt:9

  _C.self.values = {};
}, _C => {// [74]: assets/script/labyrinth_5_challenge_coordinator.txt:14

  _C.hasAllValues = true;
}, _C => {// [75]: assets/script/labyrinth_5_challenge_coordinator.txt:17

  for (let i = 0; i < 12; i++) if (_C.self.values[i] === _C.undefined) _C.hasAllValues = false;
}, _C => {// [76]: assets/script/labyrinth_5_challenge_coordinator.txt:19

  return _C.hasAllValues;
}, _C => {// [77]: assets/script/labyrinth_5_challenge_coordinator.txt:20

  _C.value1 = _C.self.values[2] + _C.self.values[7] + _C.self.values[9];
}, _C => {// [78]: assets/script/labyrinth_5_challenge_coordinator.txt:21

  _C.value2 = _C.self.values[4] + _C.self.values[5] + _C.self.values[6];
}, _C => {// [79]: assets/script/labyrinth_5_challenge_coordinator.txt:22

  _C.value3 = _C.self.values[1] ^ _C.self.values[11] ^ _C.self.values[12];
}, _C => {// [80]: assets/script/labyrinth_5_challenge_coordinator.txt:23

  _C.value4 = _C.self.values[0] + _C.self.values[3] - _C.self.values[7] + _C.self.values[8] + _C.self.values[10];
}, _C => {// [81]: assets/script/labyrinth_5_challenge_coordinator.txt:24

  _C.emit({
    type: 'labyrinth_5_event',
    value1: _C.value1,
    value2: _C.value2,
    value3: _C.value3,
    value4: _C.value4
  });
}, _C => {// [82]: assets/script/labyrinth_5_challenge_panel.txt:5

  _C.components = ['interactable'];
}, _C => {// [83]: assets/script/labyrinth_5_challenge_panel.txt:6

  _C.props = {
    coordinator: 'object',
    value_no: 'number',
    value_0: 'number',
    value_1: 'number',
    value_2: 'number',
    value_3: 'number'
  };
}, _C => {// [84]: assets/script/labyrinth_5_challenge_panel.txt:9

  _C.self.coordinator = 0;
}, _C => {// [85]: assets/script/labyrinth_5_challenge_panel.txt:10

  _C.self.value_no = 0;
}, _C => {// [86]: assets/script/labyrinth_5_challenge_panel.txt:11

  _C.self.value_0 = 0;
}, _C => {// [87]: assets/script/labyrinth_5_challenge_panel.txt:12

  _C.self.value_1 = 1;
}, _C => {// [88]: assets/script/labyrinth_5_challenge_panel.txt:13

  _C.self.value_2 = 2;
}, _C => {// [89]: assets/script/labyrinth_5_challenge_panel.txt:14

  _C.self.value_3 = 3;
}, _C => {// [90]: assets/script/labyrinth_5_challenge_panel.txt:17

  _C.interactable.interactText = "Use panel";
}, _C => {// [91]: assets/script/labyrinth_5_challenge_panel.txt:20

  _C.value_text = _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] !== _C.undefined ? _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] : 'unknown';
}, _C => {// [92]: assets/script/labyrinth_5_challenge_panel.txt:23

  _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] = _C.self.value_0;
}, _C => {// [93]: assets/script/labyrinth_5_challenge_panel.txt:25

  _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] = _C.self.value_1;
}, _C => {// [94]: assets/script/labyrinth_5_challenge_panel.txt:27

  _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] = _C.self.value_2;
}, _C => {// [95]: assets/script/labyrinth_5_challenge_panel.txt:29

  _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.values[_C.self.value_no] = _C.self.value_3;
}, _C => {// [96]: assets/script/labyrinth_5_challenge_panel.txt:31

  _C.world.entities[-_C.self.coordinator].labyrinth_5_challenge_coordinator.run('updateValues');
}, _C => {// [97]: assets/script/labyrinth_finale_panel.txt:6

  _C.components = ['interactable'];
}, _C => {// [98]: assets/script/labyrinth_finale_panel.txt:7

  _C.props = {
    gameFlagName: 'string'
  };
}, _C => {// [99]: assets/script/labyrinth_finale_panel.txt:10

  _C.self.gameFlagName = '';
}, _C => {// [100]: assets/script/labyrinth_finale_panel.txt:13

  _C.interactable.interactText = "Use panel";
}, _C => {// [101]: assets/script/labyrinth_finale_panel.txt:17

  _C.player.globalData.set(_C.self.gameFlagName, true);
}, _C => {// [102]: assets/script/labyrinth_finale_panel.txt:18

  return _C.player.globalData.get('labyrinth_flag') !== _C.undefined;
}, _C => {// [103]: assets/script/labyrinth_finale_panel.txt:22

  _C.flag = _C.player.globalData.get('labyrinth_flag');
}, _C => {// [104]: assets/script/map_simple_sign.txt:5

  _C.components = ['interactable'];
}, _C => {// [105]: assets/script/map_simple_sign.txt:6

  _C.props = {
    text: 'string'
  };
}, _C => {// [106]: assets/script/map_simple_sign.txt:9

  _C.self.text = '';
}, _C => {// [107]: assets/script/map_simple_sign.txt:12

  _C.interactable.interactText = "Read";
}, _C => {// [108]: assets/script/quest/trial_of_data.txt:5

  _C.requires = ['never'];
}, _C => {// [109]: assets/script/quest/trial_of_data.txt:6

  _C.name = 'Trial of Data';
}, _C => {// [110]: assets/script/quest/trial_of_data.txt:9

  _C.task(_C.tasks.gameGlobal('labyrinth_1_solved', true, 'Use the panel to open the gate'));
}, _C => {// [111]: assets/script/quest/trial_of_data.txt:10

  _C.task(_C.tasks.enterArea('main', 'labyrinth_1_past_gate', 'Pass through the gate'));
}, _C => {// [112]: assets/script/quest/trial_of_data.txt:12

  _C.task(_C.tasks.enterArea('main', 'labyrinth_2_near_panel', 'Find a way to the second panel'));
}, _C => {// [113]: assets/script/quest/trial_of_data.txt:13

  _C.task(_C.tasks.gameGlobal('labyrinth_2_solved', true, 'Use the panel to open the gate'));
}, _C => {// [114]: assets/script/quest/trial_of_data.txt:14

  _C.task(_C.tasks.enterArea('main', 'labyrinth_2_past_gate', 'Pass through the gate'));
}, _C => {// [115]: assets/script/quest/trial_of_data.txt:16

  _C.task(_C.tasks.enterArea('main', 'labyrinth_3_near_panel', 'Find a way to the next challenge'));
}, _C => {// [116]: assets/script/quest/trial_of_data.txt:17

  _C.task(_C.tasks.gameGlobal('labyrinth_3_solved', true, 'Solve the puzzle on the panel'));
}, _C => {// [117]: assets/script/quest/trial_of_data.txt:18

  _C.task(_C.tasks.enterArea('main', 'labyrinth_3_past_gate', 'Pass through the gate'));
}, _C => {// [118]: assets/script/quest/trial_of_data.txt:20

  _C.task(_C.tasks.enterArea('main', 'labyrinth_4_past_gate', 'Find a way to the next challenge'));
}, _C => {// [119]: assets/script/quest/trial_of_data.txt:21

  _C.task(_C.tasks.gameGlobal('labyrinth_4_solved', true, 'Interact with the panel'));
}, _C => {// [120]: assets/script/quest/trial_of_data_5.txt:5

  _C.requires = ['trial_of_data'];
}, _C => {// [121]: assets/script/quest/trial_of_data_5.txt:6

  _C.name = 'Trial of Data';
}, _C => {// [122]: assets/script/quest/trial_of_data_5.txt:9

  _C.task(_C.tasks.enterArea('main', 'labyrinth_5_area', 'Continue to the next challenge'));
}, _C => {// [123]: assets/script/quest/trial_of_data_5.txt:11

  return 46468;
}, _C => {// [124]: assets/script/quest/trial_of_data_5.txt:12

  _C.x = 21233;
}, _C => {// [125]: assets/script/quest/trial_of_data_5.txt:14

  _C.x = 24781;
}, _C => {// [126]: assets/script/quest/trial_of_data_5.txt:15

  return 6549;
}, _C => {// [127]: assets/script/quest/trial_of_data_5.txt:16

  _C.x = 48055;
}, _C => {// [128]: assets/script/quest/trial_of_data_5.txt:17

  return 0;
}, _C => {// [129]: assets/script/quest/trial_of_data_5.txt:18

  _C.x = 15874;
}, _C => {// [130]: assets/script/quest/trial_of_data_5.txt:20

  _C.x = 61986;
}, _C => {// [131]: assets/script/quest/trial_of_data_5.txt:25

  _C.task(_C.tasks.and(_C.tasks.scriptEvent({
    type: 'labyrinth_5_event',
    value1: 135975,
    value2: 118643,
    value3: 25129,
    value4: 135259
  }, 'Configure to first value'), // [4, 2, 4, 4, 3, 3, 4, 3, 4, 3, 3, 1]
  _C.tasks.scriptEvent({
    type: 'labyrinth_5_event',
    value1: 181888 ^ _C.x,
    value2: 97927 ^ _C.x,
    value3: 17422 ^ _C.x,
    value4: 22135 ^ _C.x
  }, 'Configure to second value') // [1, 1, 1, 1, 2, 2, 4, 4, 4, 1, 2, 4]
  ));
}, _C => {// [132]: assets/script/quest/trial_of_data_5.txt:26

  _C.player.globalData.set('labyrinth_5_solved', true);
}, _C => {// [133]: assets/script/quest/trial_of_data_5.txt:28

  _C.task(_C.tasks.gameGlobal('labyrinth_completed', true, 'Interact with the panel for the flag!'));
}, _C => {// [134]: assets/script/quest/trial_of_data_finale.txt:5

  _C.requires = ['trial_of_data_5'];
}, _C => {// [135]: assets/script/quest/trial_of_data_finale.txt:6

  _C.name = 'Trial of Data: Finale';
}, _C => {// [136]: assets/script/quest/trial_of_data_finale.txt:9

  _C.task(_C.tasks.gameGlobal('labyrinth_completed', true, 'Interact with the panel for the flag!'));
}, _C => {// [137]: assets/script/quest/trial_of_data_finale.txt:12

  _C.player.flagReveal.reveal('labyrinth_flag', 'TRIAL_OF_DATA');
}, _C => {// [138]: assets/script/quest/trial_of_data_finale.txt:13

  _C.task(_C.tasks.gameGlobalSet('labyrinth_flag'), 'Wait for server sync');
}, _C => {// [139]: assets/script/quest/trial_of_data_finale.txt:14

  _C.flag = _C.player.globalData.get('labyrinth_flag');
}, _C => {// [140]: assets/script/quest/tutorial.txt:5

  _C.requires = [];
}, _C => {// [141]: assets/script/quest/tutorial.txt:6

  _C.name = 'Tutorial';
}, _C => {// [142]: assets/script/quest/tutorial.txt:12

  _C.task(_C.tasks.and(_C.tasks.enterArea('main', 'tutorial_wasd', 'Walk with WASD'), _C.tasks.enterArea('main', 'tutorial_right', 'Walk to the right')));
}, _C => {// [143]: assets/script/quest/tutorial.txt:13

  _C.task(_C.tasks.enterArea('main', 'tutorial_panel', 'Walk to the panel'));
}, _C => {// [144]: assets/script/quest/tutorial.txt:14

  _C.task(_C.tasks.scriptEvent({
    type: 'tutorial_panel_interact'
  }, 'Interact with the panel using E'));
}, _C => {// [145]: assets/script/test1.txt:4

  console.log("inline console.log works!");
}, _C => {// [146]: assets/script/test1.txt:5

  let test = () => {
    console.log("inline log via function works!");
  };

  test();
}, _C => {// [147]: assets/script/test1.txt:7

  console.log("test " + "multiline");
}, _C => {// [148]: assets/script/test1.txt:8

  _C.test = 5;
}, _C => {// [149]: assets/script/test2.txt:6

  _C.choice = 1;
}, _C => {// [150]: assets/script/test2.txt:9

  _C.choice = 2;
}, _C => {// [151]: assets/script/test2.txt:19
}, _C => {// [152]: assets/script/toggle_game_flag_panel.txt:5

  _C.components = ['interactable'];
}, _C => {// [153]: assets/script/toggle_game_flag_panel.txt:6

  _C.props = {
    gameFlagName: 'string'
  };
}, _C => {// [154]: assets/script/toggle_game_flag_panel.txt:9

  _C.self.gameFlagName = '';
}, _C => {// [155]: assets/script/toggle_game_flag_panel.txt:12

  _C.value = !!_C.player.globalData.get(_C.self.gameFlagName);
}, _C => {// [156]: assets/script/toggle_game_flag_panel.txt:13

  _C.sprite.sprite = _C.value ? 'panel_on' : 'panel_off';
}, _C => {// [157]: assets/script/toggle_game_flag_panel.txt:20

  _C.value = !_C.player.globalData.get(_C.self.gameFlagName);
}, _C => {// [158]: assets/script/toggle_game_flag_panel.txt:21

  _C.sprite.sprite = _C.value ? 'panel_on' : 'panel_off';
}, _C => {// [159]: assets/script/toggle_game_flag_panel.txt:22

  _C.player.globalData.set(_C.self.gameFlagName, _C.value);
}, _C => {// [160]: assets/script/toggle_sprite.txt:5

  _C.components = ['interactable'];
}, _C => {// [161]: assets/script/toggle_sprite.txt:6

  _C.props = {
    sprite_on: 'string',
    sprite_off: 'string'
  };
}, _C => {// [162]: assets/script/toggle_sprite.txt:9

  _C.self.sprite_on = '';
}, _C => {// [163]: assets/script/toggle_sprite.txt:10

  _C.self.sprite_off = '';
}, _C => {// [164]: assets/script/toggle_sprite.txt:11

  _C.self.value = false;
}, _C => {// [165]: assets/script/toggle_sprite.txt:14

  _C.interactable.interactText = "Toggle";
}, _C => {// [166]: assets/script/toggle_sprite.txt:19

  _C.self.value = !_C.self.value;
}, _C => {// [167]: assets/script/toggle_sprite.txt:20

  _C.sprite.sprite = _C.self.value ? _C.self.sprite_on : _C.self.sprite_off;
}, _C => {// [168]: assets/script/toggle_sprite.txt:21

  _C.emit({
    type: 'toggle',
    entity: _C.transform.name,
    toValue: _C.self.value
  });
}, _C => {// [169]: assets/script/trial_of_bugs_finale_panel.txt:5

  _C.components = ['interactable'];
}, _C => {// [170]: assets/script/trial_of_bugs_finale_panel.txt:6

  _C.props = {};
}, _C => {// [171]: assets/script/trial_of_bugs_finale_panel.txt:11

  _C.interactable.interactText = "Use panel";
}, _C => {// [172]: assets/script/trial_of_bugs_finale_panel.txt:16

  _C.player.flagReveal.reveal('trial_of_bugs_flag', 'TRIAL_OF_BUGS');
}, _C => {// [173]: assets/script/trial_of_bugs_finale_panel.txt:17

  _C.task(_C.tasks.gameGlobalSet('trial_of_bugs_flag'));
}, _C => {// [174]: assets/script/trial_of_bugs_finale_panel.txt:18

  _C.flag = _C.player.globalData.get('trial_of_bugs_flag');
}];