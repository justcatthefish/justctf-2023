import * as React from 'react';

export function CheckOff() {
    return (
        <svg width="12.001" height="12" viewBox="0 0 12.001 12">
            <path d="M2,2v8h8V2H2M0,0H12V12H0Z" fill="currentColor"/>
        </svg>
    );
}
