export enum GameKey {
    MoveLeft,
    MoveRight,
    MoveUp,
    MoveDown,
    Interact,
    Max
}
